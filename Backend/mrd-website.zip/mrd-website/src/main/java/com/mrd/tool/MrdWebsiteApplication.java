package com.mrd.tool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MrdWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MrdWebsiteApplication.class, args);
	}

}
